﻿namespace MyDoctorAppointment.Data.Configuration
{
    public static class Constants
    {
        // заменить на путь валидный для вашей директории на пк (в будущем будем использовать относительный путь)
        public const string AppSettingsPath = "C:\\Users\\admin\\source\\repos\\DoctorAppointmentDemo\\DoctorAppointmentDemo.Data\\Configuration\\appsettings.json";
    }
}
