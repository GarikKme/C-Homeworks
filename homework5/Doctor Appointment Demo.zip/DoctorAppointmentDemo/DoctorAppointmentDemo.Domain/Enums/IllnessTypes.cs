﻿namespace MyDoctorAppointment.Domain.Enums
{
    public enum IllnessTypes
    {
        EyeDisease = 1,

        Infection,

        DentalDisease,

        SkinDisease,

        Ambulance,
    }
}
