﻿namespace MyDoctorAppointment.Domain.Enums
{
    public enum DoctorTypes
    {
        Dentist = 1,

        Dermatologist,

        FamilyDoctor,

        Paramedic
    }
}
